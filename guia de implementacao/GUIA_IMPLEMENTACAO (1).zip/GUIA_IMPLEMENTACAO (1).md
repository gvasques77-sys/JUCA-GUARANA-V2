# 🚀 GUIA DE IMPLEMENTAÇÃO - SISTEMA DE AGENDAMENTO
## Secretária Inteligente (JUCA GUARANA)

---

## 📋 VISÃO GERAL

Este guia vai te ajudar a adicionar funcionalidades de agendamento ao seu chatbot JUCA GUARANA.

### O que será implementado:
- ✅ Agendamento via WhatsApp (paciente conversa e agenda)
- ✅ Painel web para recepcionista gerenciar agendamentos
- ✅ Banco de dados com médicos, serviços, pacientes e agendamentos

### Arquitetura Final:
```
┌─────────────────────────────────────────────────────────────┐
│                         RAILWAY                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                    JUCA GUARANA                        │  │
│  │                                                        │  │
│  │   /chat ─────────► Agente OpenAI + Tools              │  │
│  │   /admin ────────► Dashboard Recepcionista            │  │
│  │   /admin/api ────► APIs de Agendamento                │  │
│  │                                                        │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │    SUPABASE     │
                    │  - doctors      │
                    │  - services     │
                    │  - patients     │
                    │  - appointments │
                    │  - schedules    │
                    └─────────────────┘
```

---

## 📁 ARQUIVOS CRIADOS

```
juca-guarana/
├── src/
│   ├── services/
│   │   └── schedulingService.js    ← Lógica de agendamento
│   ├── tools/
│   │   └── schedulingTools.js      ← Tools para o agente
│   └── routes/
│       └── adminRoutes.js          ← APIs do painel admin
├── public/
│   └── admin/
│       └── index.html              ← Dashboard da recepcionista
└── server.js                       ← (modificar para incluir rotas)
```

---

## 🔧 PASSO A PASSO

### PASSO 1: Criar Tabelas no Supabase

1. Acesse seu projeto no Supabase
2. Vá em **SQL Editor**
3. Cole o conteúdo do arquivo `01_supabase_tables.sql`
4. Clique em **Run**
5. Verifique se as tabelas foram criadas em **Table Editor**

**Tabelas que devem aparecer:**
- doctors
- services
- doctor_services
- schedules
- patients
- appointments
- schedule_blocks

### PASSO 2: Adicionar Variáveis de Ambiente

No Railway (ou seu .env local), adicione:

```env
# Já deve existir:
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGci...

# Adicionar:
ADMIN_PASSWORD=senha_segura_para_recepcionista
```

### PASSO 3: Criar os Novos Arquivos

No seu projeto JUCA GUARANA, crie os arquivos:

**3.1. Criar pasta e arquivo do serviço:**
```bash
mkdir -p src/services
# Copiar conteúdo de 02_schedulingService.js para:
# src/services/schedulingService.js
```

**3.2. Criar pasta e arquivo das tools:**
```bash
mkdir -p src/tools
# Copiar conteúdo de 03_schedulingTools.js para:
# src/tools/schedulingTools.js
```

**3.3. Criar pasta e arquivo das rotas admin:**
```bash
mkdir -p src/routes
# Copiar conteúdo de 05_adminRoutes.js para:
# src/routes/adminRoutes.js
```

**3.4. Criar pasta e arquivo do dashboard:**
```bash
mkdir -p public/admin
# Copiar conteúdo de 06_admin_dashboard.html para:
# public/admin/index.html
```

### PASSO 4: Modificar o Agente (agentService.js)

Abra seu arquivo do agente e faça estas modificações:

**4.1. Adicionar imports no topo:**
```javascript
const { 
    schedulingToolsDefinitions, 
    executeSchedulingTool, 
    isSchedulingTool 
} = require('./tools/schedulingTools');
```

**4.2. Adicionar as tools na lista de tools do OpenAI:**
```javascript
const ALL_TOOLS = [
    ...suasToolsExistentes,  // Se tiver
    ...schedulingToolsDefinitions
];
```

**4.3. No processamento de tool calls, adicionar:**
```javascript
// Dentro da função que processa tool calls
if (isSchedulingTool(toolName)) {
    const result = await executeSchedulingTool(toolName, args, {
        userPhone: context.userPhone
    });
    return JSON.stringify(result);
}
```

**4.4. Atualizar o System Prompt do agente:**
```javascript
const SYSTEM_PROMPT = `
Você é a secretária virtual inteligente de uma clínica médica/estética.
Seu nome é [Nome da Clínica] e você atende os pacientes pelo WhatsApp.

## SUAS RESPONSABILIDADES:
1. Agendar consultas e procedimentos
2. Informar sobre médicos e serviços disponíveis
3. Verificar horários disponíveis
4. Cancelar e remarcar consultas
5. Responder dúvidas sobre a clínica

## FLUXO DE AGENDAMENTO:
1. Pergunte qual serviço/consulta o paciente deseja
2. Mostre os médicos disponíveis para aquele serviço
3. Pergunte a data de preferência
4. Mostre os horários disponíveis
5. Confirme todos os dados antes de agendar

## REGRAS:
- SEMPRE use as tools para consultar dados reais
- NÃO invente informações sobre horários ou preços
- Sempre confirme os dados antes de finalizar
`;
```

### PASSO 5: Modificar o Server (server.js / index.js)

**5.1. Adicionar import das rotas:**
```javascript
const adminRoutes = require('./src/routes/adminRoutes');
const path = require('path');
```

**5.2. Adicionar as rotas do admin:**
```javascript
// Servir o dashboard
app.use('/admin/static', express.static(path.join(__dirname, 'public/admin')));
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/admin/index.html'));
});

// APIs do admin
app.use('/admin', adminRoutes);
```

### PASSO 6: Deploy no Railway

```bash
git add .
git commit -m "feat: adicionar sistema de agendamento"
git push
```

O Railway vai fazer o deploy automaticamente.

### PASSO 7: Testar

**7.1. Testar o Dashboard:**
- Acesse: `https://seu-app.railway.app/admin`
- Digite a senha configurada em `ADMIN_PASSWORD`
- Deve ver o painel da recepcionista

**7.2. Testar o Chatbot:**
- Envie uma mensagem no WhatsApp: "Quero agendar uma consulta"
- O bot deve responder perguntando qual serviço
- Siga o fluxo de agendamento

---

## 🎬 EXEMPLOS DE CONVERSAS

### Exemplo 1: Agendar Consulta
```
👤 Paciente: Oi, quero marcar uma consulta

🤖 Bot: Olá! Claro, posso ajudar com seu agendamento.
        Temos os seguintes serviços:
        1. Consulta Dermatológica - R$ 350
        2. Limpeza de Pele - R$ 180
        3. Botox - R$ 800
        
        Qual serviço você gostaria?

👤 Paciente: Consulta dermatológica

🤖 Bot: Ótimo! A Dra. Ana Santos é nossa dermatologista.
        Ela atende terças e quintas.
        
        Qual data você prefere?

👤 Paciente: Quinta-feira

🤖 Bot: Perfeito! Horários disponíveis para quinta (27/02):
        
        ☀️ Manhã: 09:00, 10:00, 11:00
        🌤️ Tarde: 14:00, 15:00, 16:00
        
        Qual horário você prefere?

👤 Paciente: 14h

🤖 Bot: Certo! Para confirmar, preciso do seu nome completo.

👤 Paciente: Maria Silva

🤖 Bot: ✅ Agendamento Confirmado!
        
        👤 Paciente: Maria Silva
        👨‍⚕️ Dra. Ana Santos - Dermatologia
        📅 Quinta, 27/02/2025 às 14:00
        💰 R$ 350,00
        
        Você receberá um lembrete 24h antes.
        Posso ajudar com mais alguma coisa?
```

### Exemplo 2: Cancelar Consulta
```
👤 Paciente: Preciso cancelar minha consulta

🤖 Bot: Claro! Encontrei seu agendamento:
        
        📅 Quinta, 27/02 às 14:00
        👨‍⚕️ Dra. Ana Santos
        
        Deseja realmente cancelar?

👤 Paciente: Sim

🤖 Bot: ❌ Agendamento Cancelado
        
        Se desejar reagendar, é só me avisar!
```

### Exemplo 3: Ver Agendamentos
```
👤 Paciente: Quais minhas consultas marcadas?

🤖 Bot: 📋 Suas Consultas Agendadas:
        
        1. Consulta Dermatológica
           👨‍⚕️ Dra. Ana Santos
           📅 27/02/2025 às 14:00
           📌 Status: Agendado
        
        Para cancelar ou remarcar, é só avisar!
```

---

## 🔍 TROUBLESHOOTING

### Erro: "Tool não reconhecida"
- Verifique se as tools estão sendo importadas corretamente
- Confirme que `ALL_TOOLS` inclui `schedulingToolsDefinitions`

### Erro: "Não autorizado" no Dashboard
- Verifique a variável `ADMIN_PASSWORD` no Railway
- A senha deve ser passada no header `Authorization: Bearer SENHA`

### Erro: "Tabela não existe"
- Execute novamente o SQL no Supabase
- Verifique se está usando o projeto Supabase correto

### Bot não responde sobre agendamentos
- Verifique o System Prompt do agente
- Confirme que as tools estão registradas
- Veja os logs no Railway para erros

---

## 📊 ESTRUTURA DO BANCO DE DADOS

### Relacionamentos:
```
doctors ──────┬────────── schedules (horários de atendimento)
              │
              └────────── doctor_services ──── services
                                │
patients ─────┬─────────────────┼─────────── appointments
              │                 │
              └─────────────────┘
```

### Principais Queries:
```sql
-- Ver agenda de hoje
SELECT * FROM vw_agenda_hoje;

-- Ver próximos agendamentos
SELECT * FROM vw_proximos_agendamentos;

-- Agendamentos de um médico
SELECT * FROM appointments 
WHERE doctor_id = 'xxx' 
AND appointment_date = '2025-02-27';
```

---

## 🎯 PRÓXIMOS PASSOS (OPCIONAL)

Depois de implementar o básico, você pode adicionar:

1. **Lembretes automáticos**: Enviar mensagem 24h antes da consulta
2. **Confirmação de presença**: Pedir confirmação via WhatsApp
3. **Pagamento online**: Integrar Stripe/PIX
4. **Relatórios**: Dashboard com estatísticas
5. **Múltiplas clínicas**: Suporte a várias unidades

---

## 📞 SUPORTE

Se tiver dúvidas durante a implementação:
1. Verifique os logs no Railway
2. Teste as APIs diretamente (Postman/Insomnia)
3. Consulte a documentação do Supabase

---

**Boa implementação! 🚀**
